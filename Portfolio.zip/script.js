// This script can be expanded for additional interactivity
document.addEventListener('DOMContentLoaded', function () {
    console.log("Page loaded and script running!");
});